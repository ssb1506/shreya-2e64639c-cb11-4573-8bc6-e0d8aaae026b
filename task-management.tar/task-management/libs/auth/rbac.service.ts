import { UserRole } from '../data/interfaces';

export class RBACService {
  private static roleHierarchy: Record<UserRole, number> = {
    [UserRole.OWNER]: 3,
    [UserRole.ADMIN]: 2,
    [UserRole.VIEWER]: 1,
  };

  /**
   * Check if a role has sufficient privileges
   */
  static hasRole(userRole: UserRole, requiredRoles: UserRole[]): boolean {
    return requiredRoles.some(
      (required) => this.roleHierarchy[userRole] >= this.roleHierarchy[required]
    );
  }

  /**
   * Check if user can access organization (including child organizations)
   */
  static canAccessOrganization(
    userOrgId: string,
    targetOrgId: string,
    userRole: UserRole,
    organizationTree: Map<string, string[]> // parent -> children mapping
  ): boolean {
    // User can access their own organization
    if (userOrgId === targetOrgId) {
      return true;
    }

    // Owners and Admins can access child organizations
    if (userRole === UserRole.OWNER || userRole === UserRole.ADMIN) {
      const children = organizationTree.get(userOrgId) || [];
      return children.includes(targetOrgId);
    }

    return false;
  }

  /**
   * Check if user can modify a resource
   */
  static canModifyResource(
    userRole: UserRole,
    userOrgId: string,
    resourceOrgId: string,
    resourceUserId?: string,
    currentUserId?: string
  ): boolean {
    // Owners can modify anything in their organization
    if (userRole === UserRole.OWNER && userOrgId === resourceOrgId) {
      return true;
    }

    // Admins can modify in their organization
    if (userRole === UserRole.ADMIN && userOrgId === resourceOrgId) {
      return true;
    }

    // Viewers can only modify their own resources
    if (userRole === UserRole.VIEWER) {
      return resourceUserId === currentUserId && userOrgId === resourceOrgId;
    }

    return false;
  }

  /**
   * Check if user can delete a resource
   */
  static canDeleteResource(
    userRole: UserRole,
    userOrgId: string,
    resourceOrgId: string,
    resourceUserId?: string,
    currentUserId?: string
  ): boolean {
    // Owners can delete anything in their organization
    if (userRole === UserRole.OWNER && userOrgId === resourceOrgId) {
      return true;
    }

    // Admins can delete in their organization
    if (userRole === UserRole.ADMIN && userOrgId === resourceOrgId) {
      return true;
    }

    // Viewers can only delete their own resources
    if (userRole === UserRole.VIEWER) {
      return resourceUserId === currentUserId && userOrgId === resourceOrgId;
    }

    return false;
  }
}
