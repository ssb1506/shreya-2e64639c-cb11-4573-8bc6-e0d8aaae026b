# Testing Guide

## Quick Test (5 minutes)

### Step 1: Extract and Setup
```bash
# Extract the zip file
unzip task-management.zip
cd task-management
```

### Step 2: Setup Backend
```bash
cd apps/api

# Install dependencies
npm install

# Create environment file
cp .env.example .env

# Build the application
npm run build

# Create database and seed test data
mkdir -p data
npx ts-node src/seed.ts
```

You should see:
```
✅ Database seeded successfully!

Test Users:
Owner: owner@acme.com / password123
Admin: admin@acme.com / password123
Viewer: viewer@acme.com / password123
```

### Step 3: Start Backend
```bash
# Still in apps/api directory
npm run start:dev
```

Wait for:
```
🚀 API server running on http://localhost:3000
```

### Step 4: Setup Frontend (New Terminal)
```bash
# Open a NEW terminal window
cd task-management/apps/dashboard

# Install dependencies
npm install
```

### Step 5: Start Frontend
```bash
# Still in apps/dashboard directory
npm start
```

Wait for:
```
** Angular Live Development Server is listening on localhost:4200 **
```

### Step 6: Test in Browser
Open http://localhost:4200

---

## Functional Testing Checklist

### Test 1: Authentication ✓

**Login as Owner:**
```
Email: owner@acme.com
Password: password123
```

✅ Should successfully login and redirect to dashboard
✅ Should see "Alice Owner (OWNER)" in header
✅ Should see tasks from both organizations

**Logout and Login as Viewer:**
```
Email: viewer@acme.com
Password: password123
```

✅ Should successfully login
✅ Should see "Charlie Viewer (VIEWER)" in header
✅ Should ONLY see their own tasks (fewer tasks visible)

**Test Invalid Login:**
```
Email: wrong@example.com
Password: wrong
```

❌ Should show error message
❌ Should not login

---

### Test 2: Task Creation ✓

**As Owner (owner@acme.com):**

1. Click "New Task" button
2. Fill in:
   - Title: "Test Task Creation"
   - Description: "This is a test task"
   - Category: Work
   - Status: To Do
3. Click "Create"

✅ Task should appear in TODO column
✅ Should have blue border (Work category)
✅ Statistics should update

---

### Test 3: Task Editing ✓

1. Find a task in the TODO column
2. Click the pencil icon (edit)
3. Change:
   - Title: "Updated Test Task"
   - Status: In Progress
4. Click "Update"

✅ Task should move to IN_PROGRESS column
✅ Title should be updated
✅ Statistics should update

---

### Test 4: Drag and Drop ✓

1. Find a task in TODO column
2. Click and hold on the task card
3. Drag to IN_PROGRESS column
4. Release

✅ Task should move to IN_PROGRESS
✅ Should animate smoothly
✅ Statistics should update
✅ Status persisted (refresh page to verify)

**Drag to DONE:**
1. Drag the same task to DONE column

✅ Task should move to DONE
✅ Completed count should increase

---

### Test 5: Filtering ✓

**Filter by Category:**
1. Select "Work" from Category dropdown

✅ Should only show Work tasks
✅ Other categories hidden

2. Select "Personal" from Category dropdown

✅ Should only show Personal tasks

3. Select "All Categories"

✅ Should show all tasks again

**Filter by Status:**
1. Select "In Progress" from Status dropdown

✅ Should only show tasks in IN_PROGRESS column
✅ Other columns empty or hidden

---

### Test 6: Task Deletion ✓

**As Owner:**
1. Click trash icon on any task
2. Confirm deletion

✅ Task should be removed
✅ Statistics should update

**As Viewer (viewer@acme.com):**
1. Try to delete a task created by Owner

❌ Should get 403 Forbidden error (you can only delete your own)

---

### Test 7: Role-Based Access Control ✓

**Login as Viewer (viewer@acme.com):**

✅ Can see only their own tasks
✅ Can create new tasks
✅ Can edit their own tasks
✅ Can delete their own tasks
❌ Cannot see tasks from Owner or Admin
❌ Cannot edit tasks from Owner or Admin

**Login as Admin (admin@acme.com):**

✅ Can see tasks from same organization
✅ Can see tasks from child organizations
✅ Can edit any task in their organization
✅ Can delete any task in their organization

**Login as Owner (owner@acme.com):**

✅ Can see ALL tasks (parent and child orgs)
✅ Can edit ANY task
✅ Can delete ANY task
✅ Full control

---

### Test 8: Dark Mode ✓

1. Click the sun/moon icon in header
2. Toggle between light and dark mode

✅ All components should transition smoothly
✅ Colors should change appropriately
✅ Preference should persist (reload page)

---

### Test 9: Responsive Design ✓

1. Open browser DevTools (F12)
2. Toggle device toolbar (Ctrl+Shift+M)
3. Test different screen sizes:
   - Mobile (375px)
   - Tablet (768px)
   - Desktop (1920px)

✅ Layout should adapt
✅ All features should work
✅ No horizontal scrolling
✅ Touch-friendly on mobile

---

## API Testing (using curl or Postman)

### Test 10: Direct API Calls ✓

**1. Login via API:**
```bash
curl -X POST http://localhost:3000/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"owner@acme.com","password":"password123"}'
```

Expected Response:
```json
{
  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": "...",
    "email": "owner@acme.com",
    "name": "Alice Owner",
    "role": "OWNER",
    ...
  }
}
```

Copy the `accessToken` for next steps.

**2. Get All Tasks:**
```bash
curl http://localhost:3000/tasks \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN_HERE"
```

Expected: Array of tasks

**3. Create Task:**
```bash
curl -X POST http://localhost:3000/tasks \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN_HERE" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "API Created Task",
    "description": "Created via curl",
    "category": "WORK",
    "status": "TODO"
  }'
```

Expected: Created task object with ID

**4. Update Task:**
```bash
curl -X PUT http://localhost:3000/tasks/TASK_ID_HERE \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN_HERE" \
  -H "Content-Type: application/json" \
  -d '{
    "status": "DONE"
  }'
```

Expected: Updated task object

**5. Delete Task:**
```bash
curl -X DELETE http://localhost:3000/tasks/TASK_ID_HERE \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN_HERE"
```

Expected: 200 OK

**6. Get Audit Logs (Owner/Admin only):**
```bash
curl http://localhost:3000/audit-log \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN_HERE"
```

Expected: Array of audit log entries

**7. Test Unauthorized Access:**
```bash
curl http://localhost:3000/tasks
```

Expected: 401 Unauthorized

---

## Automated Unit Tests

### Run Backend Tests:
```bash
cd apps/api
npm test
```

Expected output:
```
PASS  src/auth/rbac.service.spec.ts
PASS  src/auth/auth.service.spec.ts
PASS  src/tasks/tasks.controller.spec.ts

Test Suites: 3 passed, 3 total
Tests:       15 passed, 15 total
```

### Run with Coverage:
```bash
cd apps/api
npm run test:cov
```

Expected: Coverage report showing test coverage percentages

### Run Frontend Tests:
```bash
cd apps/dashboard
npm test
```

---

## Security Testing

### Test 11: JWT Expiration ✓

1. Login and get a token
2. Wait 24 hours OR manually modify token
3. Try to access protected endpoint

❌ Should return 401 Unauthorized
✅ Should redirect to login

### Test 12: Password Security ✓

1. Check database file: `apps/api/data/task-management.db`
2. Open with SQLite browser
3. View users table

✅ Passwords should be hashed (bcrypt)
✅ Should NOT see plain text passwords

### Test 13: RBAC Enforcement ✓

**As Viewer, try to access Admin endpoint:**
```bash
# Login as Viewer
curl -X POST http://localhost:3000/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"viewer@acme.com","password":"password123"}'

# Try to access audit logs
curl http://localhost:3000/audit-log \
  -H "Authorization: Bearer VIEWER_TOKEN"
```

❌ Should return 403 Forbidden

### Test 14: Organization Isolation ✓

1. Login as Viewer (child organization)
2. Note your organization tasks
3. Login as Owner (parent organization)

✅ Owner should see child org tasks
✅ Owner should see parent org tasks
✅ Viewer should NOT see parent org tasks

---

## Performance Testing

### Test 15: Multiple Concurrent Requests ✓

```bash
# Create 10 tasks simultaneously
for i in {1..10}; do
  curl -X POST http://localhost:3000/tasks \
    -H "Authorization: Bearer YOUR_TOKEN" \
    -H "Content-Type: application/json" \
    -d "{\"title\":\"Task $i\",\"description\":\"Test\",\"category\":\"WORK\"}" &
done
wait
```

✅ All tasks should be created
✅ No race conditions
✅ Database should be consistent

---

## Common Issues & Solutions

### Issue: Port 3000 already in use
```bash
# Find process
lsof -i :3000  # Mac/Linux
netstat -ano | findstr :3000  # Windows

# Kill process or change port in .env
PORT=3001
```

### Issue: Port 4200 already in use
```bash
# Start on different port
ng serve --port 4201
```

### Issue: Database locked
```bash
# Stop all processes
# Delete and recreate database
cd apps/api
rm -rf data
mkdir -p data
npx ts-node src/seed.ts
```

### Issue: Module not found
```bash
# Reinstall dependencies
rm -rf node_modules package-lock.json
npm install
```

### Issue: CORS errors
```bash
# Check .env file
FRONTEND_URL=http://localhost:4200

# Restart backend
```

---

## Test Results Checklist

After running all tests, you should have verified:

- [x] Authentication works (login/logout)
- [x] JWT tokens are properly generated and validated
- [x] All three roles behave correctly (OWNER, ADMIN, VIEWER)
- [x] Tasks can be created, read, updated, deleted
- [x] Drag and drop works smoothly
- [x] Filters work correctly
- [x] Dark mode toggles properly
- [x] Responsive design works on all screen sizes
- [x] API endpoints return correct responses
- [x] RBAC prevents unauthorized access
- [x] Organization hierarchy works correctly
- [x] Audit logs are created
- [x] Unit tests pass
- [x] Security measures are in place

---

## Video Recording Test Run

If recording a demo video, follow this sequence:

1. **Login as Owner** - Show dashboard with all tasks
2. **Create a task** - Demonstrate the modal
3. **Drag and drop** - Move task between columns
4. **Filter tasks** - Show category and status filters
5. **Toggle dark mode** - Show theme switching
6. **Edit task** - Modify an existing task
7. **Logout and login as Viewer** - Show limited access
8. **Show API test** - Run curl command in terminal
9. **Show code** - Briefly show RBAC implementation
10. **Show tests passing** - Run `npm test`

Total time: ~8-10 minutes

---

**All tests passing means your system is working correctly!** 🎉
