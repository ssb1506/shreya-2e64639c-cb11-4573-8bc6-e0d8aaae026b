import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, tap } from 'rxjs';
import { Task, CreateTaskDto, UpdateTaskDto } from '../../../../../libs/data/interfaces';
import { environment } from '../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class TaskService {
  private tasksSubject = new BehaviorSubject<Task[]>([]);
  public tasks$ = this.tasksSubject.asObservable();

  constructor(private http: HttpClient) {}

  loadTasks(): Observable<Task[]> {
    return this.http.get<Task[]>(`${environment.apiUrl}/tasks`)
      .pipe(
        tap(tasks => this.tasksSubject.next(tasks))
      );
  }

  createTask(task: CreateTaskDto): Observable<Task> {
    return this.http.post<Task>(`${environment.apiUrl}/tasks`, task)
      .pipe(
        tap(newTask => {
          const tasks = [...this.tasksSubject.value, newTask];
          this.tasksSubject.next(tasks);
        })
      );
  }

  updateTask(id: string, task: UpdateTaskDto): Observable<Task> {
    return this.http.put<Task>(`${environment.apiUrl}/tasks/${id}`, task)
      .pipe(
        tap(updatedTask => {
          const tasks = this.tasksSubject.value.map(t =>
            t.id === id ? updatedTask : t
          );
          this.tasksSubject.next(tasks);
        })
      );
  }

  deleteTask(id: string): Observable<void> {
    return this.http.delete<void>(`${environment.apiUrl}/tasks/${id}`)
      .pipe(
        tap(() => {
          const tasks = this.tasksSubject.value.filter(t => t.id !== id);
          this.tasksSubject.next(tasks);
        })
      );
  }

  getTasks(): Task[] {
    return this.tasksSubject.value;
  }
}
